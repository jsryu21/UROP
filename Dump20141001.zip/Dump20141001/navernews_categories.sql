CREATE DATABASE  IF NOT EXISTS `navernews` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `navernews`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: navernews
-- ------------------------------------------------------
-- Server version	5.1.41-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'뉴스','big',NULL),(2,'정치','medium',1),(3,'경제','medium',1),(4,'사회','medium',1),(5,'생활/문화','medium',1),(6,'세계','medium',1),(7,'IT/과학','medium',1),(8,'연예','medium',1),(9,'스포츠','big',NULL),(10,'야구','medium',9),(11,'축구','medium',9),(12,'골프','medium',9),(13,'농구/배구','medium',9),(14,'스포츠 일반','medium',9),(15,'e스포츠','medium',9),(16,'경마','medium',9),(17,'K리그 뉴스','medium',9),(18,'바둑','medium',9),(19,'피겨스케이트','medium',9),(20,'정치 일반','small',2),(21,'행정','small',2),(22,'국회/정당','small',2),(23,'국방/외교','small',2),(24,'북한','small',2),(25,'청와대','small',2),(26,'정부기관-부·처','small',2),(27,'정부기관-청·위원회','small',2),(28,'2014 지방선거','small',2),(29,'기타','small',2),(30,'생활/문화 일반','small',5),(31,'자동차/시승기','small',5),(32,'건강정보','small',5),(33,'여행/레저','small',5),(34,'패션/뷰티','small',5),(35,'생활/문화 기타','small',5),(36,'공연/전시','small',5),(37,'날씨','small',5),(38,'음식/맛집','small',5),(39,'종교','small',5),(40,'책','small',5),(41,'도로/교통','small',5),(42,'가정/육아','small',5),(43,'기업/재계','small',3),(44,'부동산','small',3),(45,'금융','small',3),(46,'증권','small',3),(47,'경제 일반','small',3),(48,'글로벌경제','small',3),(49,'경제 기타','small',3),(50,'생활경제','small',3),(51,'재테크','small',3),(52,'공시/메모','small',3),(53,'해외증시','small',3),(54,'교육','small',4),(55,'사건사고','small',4),(56,'지역','small',4),(57,'언론','small',4),(58,'사회 일반','small',4),(59,'인물','small',4),(60,'사회 기타','small',4),(61,'식품/의료','small',4),(62,'노동','small',4),(63,'인권/복지','small',4),(64,'환경','small',4),(65,'여성','small',4),(66,'국내 농구','small',13),(67,'배구','small',13),(68,'해외 농구','small',13),(69,'일문','small',6),(70,'아시아/호주','small',6),(71,'영문','small',6),(72,'지구촌 화제','small',6),(73,'세계 일반','small',6),(74,'미국/중남미','small',6),(75,'유럽','small',6),(76,'중동/아프리카','small',6),(77,'해외축구','small',11),(78,'국내축구','small',11),(79,'한국대표팀','small',11),(80,'IT 일반','small',7),(81,'게임/리뷰','small',7),(82,'통신/뉴미디어','small',7),(83,'과학 일반','small',7),(84,'컴퓨터','small',7),(85,'인터넷/SNS','small',7),(86,'모바일','small',7),(87,'보안/해킹','small',7),(88,'연예 일반','small',8),(89,'연예가화제','small',8),(90,'방송/TV','small',8),(91,'영화','small',8),(92,'드라마','small',8),(93,'Opinion','small',8),(94,'해외 연예','small',8),(95,'DVD','small',8),(96,'국내야구','small',10),(97,'메이저리그','small',10),(98,'일본야구','small',10),(99,'골프 일반','small',12),(100,'분류없음','big',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-01  2:25:05
